package mavenTestNGHomework.pageObject;

public class Footer {


}
