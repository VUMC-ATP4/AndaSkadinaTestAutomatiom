package seleniumHomework;


import io.cucumber.java.bs.A;
import org.openqa.selenium.devtools.v85.log.Log;
import org.openqa.selenium.WebElement;
import pageObjectsHomework.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class sauceDemoTests {
    WebDriver driver;
    WebDriverWait wait;
    public final String SAUCELABS_URL = "https://www.saucedemo.com/";

    @BeforeMethod
    public void setupBrowser(){
        driver = new ChromeDriver();
        // atvērt pilnā logā
        driver.manage().window().maximize();
        System.out.println("Pirms testa");
        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));//otrs variants


    }
    //1.Scenārijs
    @Test
    public void sucessLoginPageObject() throws InterruptedException {
        driver.get(SAUCELABS_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.getUsernameInputField().sendKeys("standard_user");
        loginPage.getPasswordInputField().sendKeys("secret_sauce");
        loginPage.getLoginButton().click();
        Thread.sleep(5000);
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.saucedemo.com/inventory.html");

        InventoryPage inventoryPage = new InventoryPage(driver);
        Assert.assertEquals(inventoryPage.getPageTitle().getText(),"PRODUCTS");
        inventoryPage.getAddToCartButtonBackpack().click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
        //Thread.sleep(1000);

        CartPage cartPage = new CartPage(driver);
        cartPage.getCartLink().click();
       // wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);
        Assert.assertEquals(cartPage.getCartContentsSaucelabsBackpack().getText(),"Sauce Labs Backpack");
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);

        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.getCheckoutButton().click();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);
        checkoutPage.getInputFirstName().sendKeys("Anda");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
//        Thread.sleep(1000);
        checkoutPage.getInputLastName().sendKeys("Skadina");
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);
        checkoutPage.getInputPostalCode().sendKeys("LV3018");
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);
        checkoutPage.getContinueButton().click();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);

        CheckoutOverviewPage checkoutOverviewPage = new CheckoutOverviewPage(driver);
       Assert.assertEquals(checkoutOverviewPage.getInventoryItemName().getText(),"Sauce Labs Backpack");
       Assert.assertEquals(checkoutOverviewPage.getpaymentInformation().getText(),"Payment Information:");
       Assert.assertEquals(checkoutOverviewPage.getPaymentInformationNr().getText(),"SauceCard #31337");
        Assert.assertEquals(checkoutOverviewPage.getShippingInformation().getText(),"Shipping Information:");
        Assert.assertEquals(checkoutOverviewPage.getShippingInformationWhere().getText(), "FREE PONY EXPRESS DELIVERY!");
        Assert.assertEquals(checkoutOverviewPage.getItemTotal().getText(),"Item total: $29.99");
        Assert.assertEquals(checkoutOverviewPage.getTaxr().getText(),"Tax: $2.40");
        Assert.assertEquals(checkoutOverviewPage.getTotal().getText(),"Total: $32.39");
        checkoutOverviewPage.getFinishButton().click();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);

        CheckoutSuccessPage checkoutSuccessPage = new CheckoutSuccessPage(driver);
        Assert.assertEquals(checkoutSuccessPage.getCheckoutComplete().getText(),"CHECKOUT: COMPLETE!");
        checkoutSuccessPage.getBackHomeButton().click();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        Thread.sleep(1000);
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.saucedemo.com/inventory.html");








        //Checkout - nav ievadīts nekas un nav vārds un ir tikai pasta kods - Error: First Name is required
        //Nav ievadīts uzv;ards -Error: Last Name is required
        //Error: Postal Code is required
        //produkts grozā = Sauce Labs Backpack


    }


    @AfterMethod
    public void tearDownBrowser(){
        System.out.println("Pēc testa");
        driver.close();

    }

}
